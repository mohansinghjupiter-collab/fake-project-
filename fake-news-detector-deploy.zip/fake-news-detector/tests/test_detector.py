"""Fast unit tests. Run with:  pytest -q"""

from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from fake_news_detector import preprocess, reasoning, reputation  # noqa: E402
from fake_news_detector.detector import Detector  # noqa: E402
from fake_news_detector.features import StylometricFeatures  # noqa: E402
from fake_news_detector.model import DEFAULT_MODEL_PATH, FakeNewsModel  # noqa: E402


# --------------------------------------------------------------------- preprocess
def test_normalize_strips_html_urls_punctuation():
    out = preprocess.normalize("<p>Hello, WORLD! Visit https://x.com now</p>")
    assert out == "hello world visit now"


def test_content_tokens_remove_stopwords():
    tokens = preprocess.content_tokens("The quick brown fox jumps over the lazy dog")
    assert "the" not in tokens
    assert "quick" in tokens and "fox" in tokens


def test_extract_urls_host():
    assert preprocess.extract_urls("see https://www.reuters.com/a/b") == ["reuters.com"]


# -------------------------------------------------------------------- stylometry
def test_stylometry_shape_and_names():
    st = StylometricFeatures()
    X = st.transform(["Wow!!! The TRUTH is out there.", "A measured sentence."])
    assert X.shape == (2, len(StylometricFeatures.FEATURE_NAMES))
    assert list(st.get_feature_names_out())[0] == StylometricFeatures.FEATURE_NAMES[0]


# -------------------------------------------------------------------- reputation
def test_reputation_known_reliable_domain():
    res = reputation.check_reputation("As reported by reuters.com today.")
    assert res.reputation_known is True
    assert res.score <= 0.2


def test_reputation_known_weak_domain():
    res = reputation.check_reputation("Read it on worldnewsdailyreport.com")
    assert res.reputation_known is True
    assert res.score >= 0.6


def test_reputation_unknown_is_neutral():
    res = reputation.check_reputation("Some words with no domain at all.")
    assert res.reputation_known is False
    assert res.score == 0.5


# --------------------------------------------------------------------- reasoning
def test_heuristic_reason_flags_sensational():
    res = reasoning.heuristic_reason(
        "SHOCKING!! You won't believe what they are hiding. Share this before it's deleted!!!"
    )
    assert res.backend == "heuristic"
    assert res.score >= 0.5
    assert res.red_flags


def test_heuristic_reason_neutral_is_low():
    res = reasoning.heuristic_reason(
        "According to a statement, the spokesperson confirmed the report; the study was peer-reviewed."
    )
    assert res.score <= 0.3


# ------------------------------------------------------------------ detector core
def test_detector_without_model_renormalises_weights():
    det = Detector(model=None, prefer_llm=False)
    res = det.detect("SHOCKING miracle cure they don't want you to know! Share now!!!")
    assert det.has_model is False
    assert set(res.signals) == {"reasoning", "reputation"}
    assert abs(sum(res.weights.values()) - 1.0) < 1e-6
    assert res.verdict in {"Likely Fake", "Likely Real", "Uncertain"}


def test_detector_empty_text_raises():
    det = Detector(model=None, prefer_llm=False)
    with pytest.raises(ValueError):
        det.detect("   ")


def test_detector_result_serialisable():
    det = Detector(model=None, prefer_llm=False)
    d = det.detect("Some ordinary reporting about a council meeting on Tuesday.").as_dict()
    assert {"verdict", "fake_probability", "signals", "weights"} <= set(d)


# ---------------------------------------------------------------- trained model
@pytest.mark.skipif(not os.path.exists(DEFAULT_MODEL_PATH), reason="model not trained")
def test_trained_model_predicts_and_explains():
    model = FakeNewsModel.load(DEFAULT_MODEL_PATH)
    assert model.is_fitted
    p_fake = model.predict_proba_fake("SHOCKING!! miracle cure they don't want you to know!!!")
    assert 0.0 <= p_fake <= 1.0
    expl = model.explain("according to a statement the spokesperson confirmed the report")
    assert expl.fake_terms or expl.real_terms
