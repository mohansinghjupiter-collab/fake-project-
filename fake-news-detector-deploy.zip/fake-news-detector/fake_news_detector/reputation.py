"""The source / reputation signal.

This layer answers a different question from the text classifier: *where did
this come from, and does that place have a track record?* It does two things:

1. Looks up any domains mentioned in the text against a curated reliability
   table (editable via ``data/sources.csv``).
2. Checks attribution hygiene - does the piece name a source, quote anyone,
   carry a dateline? Anonymous, source-free writing is a risk cue.

The output is a "fake-leaning" score in [0, 1] where 0.5 is neutral.
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass, field

# Curated reliability map. 0.0 = reliable / established, 1.0 = notorious for
# fabrication or hoaxes. Values are deliberately coarse - this is a prior, not
# a verdict. Extend or override via data/sources.csv.
_CURATED: dict[str, tuple[float, str]] = {
    # Wire services & established outlets
    "reuters.com": (0.02, "Established wire service"),
    "apnews.com": (0.02, "Established wire service"),
    "afp.com": (0.03, "Established wire service"),
    "bbc.com": (0.05, "Established public broadcaster"),
    "bbc.co.uk": (0.05, "Established public broadcaster"),
    "npr.org": (0.06, "Established public broadcaster"),
    "nytimes.com": (0.07, "Major newspaper of record"),
    "washingtonpost.com": (0.08, "Major newspaper"),
    "wsj.com": (0.08, "Major newspaper"),
    "theguardian.com": (0.08, "Major newspaper"),
    "economist.com": (0.07, "Established magazine"),
    "nature.com": (0.03, "Peer-reviewed journal"),
    "science.org": (0.03, "Peer-reviewed journal"),
    "who.int": (0.05, "Official health agency"),
    "cdc.gov": (0.05, "Official health agency"),
    "nasa.gov": (0.04, "Official space agency"),
    "gov.uk": (0.06, "Government source"),
    "europa.eu": (0.06, "Government source"),
    "snopes.com": (0.05, "Fact-checking site"),
    "politifact.com": (0.05, "Fact-checking site"),
    "factcheck.org": (0.05, "Fact-checking site"),
    "fullfact.org": (0.05, "Fact-checking site"),
    "leadstories.com": (0.08, "Fact-checking site"),
    # Mixed / tabloid: high volume, variable accuracy
    "dailymail.co.uk": (0.45, "Tabloid, mixed accuracy"),
    "thesun.co.uk": (0.5, "Tabloid, mixed accuracy"),
    "nypost.com": (0.4, "Tabloid, mixed accuracy"),
    "mirror.co.uk": (0.45, "Tabloid, mixed accuracy"),
    "express.co.uk": (0.5, "Tabloid, mixed accuracy"),
    "rt.com": (0.6, "State-controlled, propaganda concerns"),
    "sputniknews.com": (0.75, "State-controlled, propaganda concerns"),
    "infowars.com": (0.9, "Repeated purveyor of false claims"),
    "naturalnews.com": (0.9, "Repeated purveyor of false claims"),
    "beforeitsnews.com": (0.9, "Repeated purveyor of false claims"),
    "worldnewsdailyreport.com": (0.97, "Satire / hoax site"),
    "theonion.com": (0.05, "Satire (clearly labelled)"),
    "thebabylonbee.com": (0.05, "Satire (clearly labelled)"),
    "clickhole.com": (0.05, "Satire (clearly labelled)"),
}

# Words that signal a *lack* of sourcing.
_VAGUE_ATTRIBUTION = (
    "reportedly",
    "sources say",
    "sources claim",
    "it is said",
    "rumor",
    "rumour",
    "allegedly",
    "some say",
    "many people are saying",
    "people are saying",
    "insiders say",
    "anonymous source",
)
# Words that signal *good* sourcing.
_STRONG_ATTRIBUTION = (
    "according to",
    "said in a statement",
    "told reuters",
    "told the associated press",
    "confirmed by",
    "spokesperson",
    "press release",
    "peer-reviewed",
    "study published",
    "data from",
    "official report",
    "court filings",
)


@dataclass
class ReputationResult:
    score: float  # fake-leaning, 0..1 (0.5 = neutral / unknown)
    domains: list[str] = field(default_factory=list)
    known_domains: list[tuple[str, float, str]] = field(default_factory=list)
    flags: list[str] = field(default_factory=list)
    reputation_known: bool = False

    def as_dict(self) -> dict:
        return {
            "score": round(self.score, 4),
            "domains": self.domains,
            "known_domains": [
                {"domain": d, "reliability_score": round(1 - s, 3), "note": n}
                for d, s, n in self.known_domains
            ],
            "flags": self.flags,
            "reputation_known": self.reputation_known,
        }


_CSV_CACHE: dict[str, tuple[float, str]] | None = None


def load_source_table(path: str | None = None) -> dict[str, tuple[float, str]]:
    """Merge the curated table with an optional user-editable CSV.

    The CSV is expected to have columns ``domain,fake_score,note`` (a header is
    detected automatically). User rows override the curated values.
    """
    table = dict(_CURATED)
    if path and os.path.exists(path):
        try:
            with open(path, newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                if reader.fieldnames and "domain" in reader.fieldnames:
                    for row in reader:
                        domain = (row.get("domain") or "").strip().lower()
                        # Skip blank lines and '#' comment lines.
                        if not domain or domain.startswith("#"):
                            continue
                        try:
                            score = float(row.get("fake_score", 0.5))
                        except (TypeError, ValueError):
                            continue
                        table[domain] = (score, (row.get("note") or "").strip())
        except OSError:
            pass
    return table


def _domains_in_text(text: str, table: dict[str, tuple[float, str]]) -> list[str]:
    """Find table domains referenced anywhere in the text (substring match).

    This catches both bare mentions ("per reuters.com") and full URLs.
    """
    lowered = (text or "").lower()
    found = [d for d in table if d in lowered]
    # Longest first so 'bbc.co.uk' wins over 'bbc.com' when both somehow match.
    return sorted(found, key=len, reverse=True)


def check_reputation(text: str, source_url: str | None = None, table=None) -> ReputationResult:
    table = table if table is not None else load_source_table()
    haystack = " ".join(filter(None, [text or "", source_url or ""]))

    domains = _domains_in_text(haystack, table)
    known: list[tuple[str, float, str]] = []
    flags: list[str] = []

    # Deduplicate overlapping matches (e.g. a subdomain also matching the apex).
    chosen: list[str] = []
    for d in domains:
        if not any(d in c for c in chosen):
            chosen.append(d)
    for d in chosen:
        score, note = table[d]
        known.append((d, score, note))

    lowered = (text or "").lower()
    vague_hits = [p for p in _VAGUE_ATTRIBUTION if p in lowered]
    strong_hits = [p for p in _STRONG_ATTRIBUTION if p in lowered]

    if known:
        # Weight by the most extreme (most informative) domain found.
        domain_score = max(k[1] for k in known) if max(k[1] for k in known) >= 0.5 else min(
            k[1] for k in known
        )
        score = domain_score
        reputation_known = True
        for d, s, note in known:
            if s >= 0.6:
                flags.append(f"Cited source '{d}' has a weak reliability record ({note}).")
            elif s <= 0.1:
                flags.append(f"Cited source '{d}' is well established ({note}).")
    else:
        score = 0.5
        reputation_known = False
        flags.append("No recognisable news domain found - source cannot be verified.")

    # Attribution hygiene nudges the score either way.
    if vague_hits and not strong_hits:
        score = min(1.0, score + 0.12)
        flags.append(
            "Relies on vague attribution (" + ", ".join(f"'{v}'" for v in vague_hits[:3]) + ")."
        )
    if strong_hits:
        score = max(0.0, score - 0.08)
        flags.append("Uses concrete attribution (" + ", ".join(f"'{v}'" for v in strong_hits[:2]) + ").")
    if not strong_hits and not vague_hits:
        flags.append("No named sourcing or quotes detected.")

    return ReputationResult(
        score=float(max(0.0, min(1.0, score))),
        domains=chosen,
        known_domains=known,
        flags=flags,
        reputation_known=reputation_known,
    )
