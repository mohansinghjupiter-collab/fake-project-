"""The orchestrator: blend the three signals into one verdict."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from . import reasoning, reputation
from .model import DEFAULT_MODEL_PATH, FakeNewsModel

# Default blending weights. They are re-normalised at runtime whenever a signal
# is unavailable (e.g. no trained model, or no recognisable source).
DEFAULT_WEIGHTS = {"ml": 0.55, "reasoning": 0.25, "reputation": 0.20}

FAKE_THRESHOLD = 0.62
REAL_THRESHOLD = 0.38

_SOURCES_CSV = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "sources.csv"
)


@dataclass
class DetectionResult:
    verdict: str
    fake_probability: float
    confidence: str
    signals: dict = field(default_factory=dict)
    weights: dict = field(default_factory=dict)
    red_flags: list[str] = field(default_factory=list)
    green_flags: list[str] = field(default_factory=list)
    explanation: dict = field(default_factory=dict)
    summary: str = ""

    def as_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "fake_probability": round(self.fake_probability, 4),
            "confidence": self.confidence,
            "signals": {k: round(v, 4) if isinstance(v, float) else v for k, v in self.signals.items()},
            "weights": self.weights,
            "red_flags": self.red_flags,
            "green_flags": self.green_flags,
            "explanation": self.explanation,
            "summary": self.summary,
        }


class Detector:
    """Combine ML, AI-reasoning and source-reputation signals.

    Parameters
    ----------
    model:
        A fitted :class:`FakeNewsModel`, or ``None`` to run without the ML signal.
    weights:
        Override the default blending weights.
    """

    def __init__(
        self,
        model: FakeNewsModel | None = None,
        weights: dict | None = None,
        sources_csv: str | None = _SOURCES_CSV,
        prefer_llm: bool = True,
    ):
        self.model = model
        self.weights = dict(weights or DEFAULT_WEIGHTS)
        self.prefer_llm = prefer_llm
        self.source_table = reputation.load_source_table(sources_csv)

    # ------------------------------------------------------------------ load
    @classmethod
    def load_default(cls, model_path: str = DEFAULT_MODEL_PATH, **kwargs) -> "Detector":
        """Load the trained model if present; otherwise degrade gracefully."""
        model = None
        if os.path.exists(model_path):
            model = FakeNewsModel.load(model_path)
        return cls(model=model, **kwargs)

    @property
    def has_model(self) -> bool:
        return self.model is not None and getattr(self.model, "is_fitted", False)

    # ---------------------------------------------------------------- detect
    def detect(self, text: str, title: str = "", source_url: str = "") -> DetectionResult:
        if not (text or "").strip():
            raise ValueError("No text supplied to analyse.")

        document = f"{title}\n{text}".strip()

        # --- signal 1: ML model -------------------------------------------
        ml_score: float | None = None
        explanation: dict = {}
        if self.has_model:
            ml_score = float(self.model.predict_proba_fake(document))
            expl = self.model.explain(document, top_k=6)
            explanation = {
                "fake_terms": [{"term": t, "weight": round(w, 4)} for t, w in expl.fake_terms],
                "real_terms": [{"term": t, "weight": round(w, 4)} for t, w in expl.real_terms],
            }

        # --- signal 2: AI reasoning ---------------------------------------
        reason = reasoning.reason(document, prefer_llm=self.prefer_llm)

        # --- signal 3: source reputation ----------------------------------
        rep = reputation.check_reputation(document, source_url=source_url, table=self.source_table)

        # --- blend ---------------------------------------------------------
        available = {"ml": ml_score, "reasoning": reason.score, "reputation": rep.score}
        active = {k: v for k, v in available.items() if v is not None}
        total_w = sum(self.weights.get(k, 0.0) for k in active) or 1.0
        used_weights = {k: round(self.weights.get(k, 0.0) / total_w, 4) for k in active}
        blended = sum(active[k] * used_weights[k] for k in active)

        verdict = self._verdict(blended)
        confidence = self._confidence(blended, active)

        # --- flags & explanation ------------------------------------------
        red = list(reason.red_flags)
        green = list(reason.green_flags)
        for flag in rep.flags:
            # Reputation produces both worrying and reassuring notes; route them.
            if "well established" in flag or "clearly labelled" in flag:
                green.append(flag)
            else:
                red.append(flag)
        if not rep.reputation_known:
            # "no domain found" is informational, not necessarily red.
            red = [f for f in red if not f.startswith("No recognisable")]
        if self.has_model and ml_score is not None and ml_score >= 0.7:
            top = ", ".join(d["term"] for d in explanation.get("fake_terms", [])[:4])
            red.append(f"Classifier matched fabricated-style vocabulary: {top}.")
        if self.has_model and ml_score is not None and ml_score <= 0.3:
            top = ", ".join(d["term"] for d in explanation.get("real_terms", [])[:4])
            green.append(f"Classifier matched straightforward news vocabulary: {top}.")

        summary = self._summary(verdict, blended, active, reason, rep)

        return DetectionResult(
            verdict=verdict,
            fake_probability=blended,
            confidence=confidence,
            signals={k: float(v) for k, v in active.items()},
            weights=used_weights,
            red_flags=red,
            green_flags=green,
            explanation=explanation,
            summary=summary,
        )

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _verdict(score: float) -> str:
        if score >= FAKE_THRESHOLD:
            return "Likely Fake"
        if score <= REAL_THRESHOLD:
            return "Likely Real"
        return "Uncertain"

    @staticmethod
    def _confidence(score: float, active: dict) -> str:
        distance = abs(score - 0.5) * 2  # 0 at the boundary, 1 at the extremes
        # Fewer active signals -> less certainty overall.
        coverage = len(active) / 3
        adj = distance * (0.5 + 0.5 * coverage)
        if adj >= 0.6:
            return "high"
        if adj >= 0.3:
            return "medium"
        return "low"

    @staticmethod
    def _summary(verdict, score, active, reason, rep) -> str:
        parts = [f"Overall assessment: {verdict} ({score:.0%} fake-leaning)."]
        if "ml" in active:
            parts.append(f"Text classifier: {active['ml']:.0%}.")
        parts.append(f"Language analysis: {active.get('reasoning', 0):.0%}.")
        if rep.reputation_known:
            parts.append(
                "Source check: recognised "
                + ", ".join(d for d, _, _ in rep.known_domains)
                + f" ({active.get('reputation', 0):.0%})."
            )
        else:
            parts.append("Source check: no recognised domain cited.")
        parts.append(reason.summary)
        return " ".join(parts)
