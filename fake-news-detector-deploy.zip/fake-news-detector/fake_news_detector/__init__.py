"""
fake_news_detector
==================

A Python fake-news detector that combines three independent signal families:

1. **ML model**   - a scikit-learn text classifier (word + character TF-IDF plus
                    stylometric features) that outputs P(fake).
2. **AI reasoning** - either an LLM judgment (if an OpenAI-compatible endpoint is
                    configured) or a transparent, rule-based linguistic analyser
                    that runs fully offline.
3. **Source reputation** - a curated domain-reliability lookup plus simple
                    attribution checks.

The three signals are blended into a single calibrated score, a plain-language
verdict, and an explanation listing the strongest contributing cues.

    >>> from fake_news_detector import Detector
    >>> det = Detector.load_default()
    >>> result = det.detect("SHOCKING!! You won't believe what they're hiding...")
    >>> result.verdict
    'Likely Fake'
"""

from .detector import Detector, DetectionResult
from .model import FakeNewsModel
from . import reputation, reasoning, preprocess

__all__ = [
    "Detector",
    "DetectionResult",
    "FakeNewsModel",
    "reputation",
    "reasoning",
    "preprocess",
]

__version__ = "1.0.0"
