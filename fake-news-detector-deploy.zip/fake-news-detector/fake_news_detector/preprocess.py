"""Text normalisation and tokenisation helpers.

Everything here is deliberately dependency-light: no NLTK corpora downloads, no
network calls. The stop-word list is a small built-in set that is more than
enough for TF-IDF feature extraction.
"""

from __future__ import annotations

import re
import unicodedata

_URL_RE = re.compile(r"https?://\S+|www\.\S+")
_HTML_RE = re.compile(r"<[^>]+>")
_NON_WORD_RE = re.compile(r"[^a-z0-9\s']")
_WS_RE = re.compile(r"\s+")
_TOKEN_RE = re.compile(r"[a-z0-9']+")

# A compact English stop-word list. Kept inline so the package never has to
# download anything at runtime.
STOPWORDS: frozenset[str] = frozenset(
    """
    a about above after again against all am an and any are aren't as at be
    because been before being below between both but by can't cannot could
    couldn't did didn't do does doesn't doing don't down during each few for
    from further had hadn't has hasn't have haven't having he he'd he'll he's
    her here here's hers herself him himself his how how's i i'd i'll i'm i've
    if in into is isn't it it's its itself let's me more most mustn't my myself
    no nor not of off on once only or other ought our ours ourselves out over
    own same shan't she she'd she'll she's should shouldn't so some such than
    that that's the their theirs them themselves then there there's these they
    they'd they'll they're they've this those through to too under until up
    very was wasn't we we'd we'll we're we've were weren't what what's when
    when's where where's which while who who's whom why why's with won't would
    wouldn't you you'd you'll you're you've your yours yourself yourselves
    """.split()
)


# Same list, but pre-vetted for scikit-learn's default token_pattern (which
# splits on apostrophes). Passing only single alphabetic tokens here keeps the
# vectorizer's stop-word consistency check quiet.
SKLEARN_STOPWORDS: tuple[str, ...] = tuple(sorted(w for w in STOPWORDS if w.isalpha()))


def strip_html(text: str) -> str:
    """Remove HTML tags and unescape the most common entities."""
    text = _HTML_RE.sub(" ", text or "")
    for entity, char in (
        ("&amp;", "&"),
        ("&nbsp;", " "),
        ("&#39;", "'"),
        ("&quot;", '"'),
        ("&lt;", "<"),
        ("&gt;", ">"),
    ):
        text = text.replace(entity, char)
    return text


def normalize(text: str) -> str:
    """Lowercase, strip URLs/HTML/punctuation and collapse whitespace.

    Used to build the bag-of-words representation. Keeping punctuation out of
    this view is intentional - punctuation cues are captured separately by the
    stylometric features so they are not lost.
    """
    text = unicodedata.normalize("NFKC", text or "")
    text = strip_html(text)
    text = _URL_RE.sub(" ", text)
    text = text.lower()
    text = text.replace("\u2019", "'")
    text = _NON_WORD_RE.sub(" ", text)
    text = _WS_RE.sub(" ", text).strip()
    return text


def tokenize(text: str) -> list[str]:
    """Return word tokens from already-normalised text."""
    return _TOKEN_RE.findall(text)


def content_tokens(text: str, remove_stopwords: bool = True) -> list[str]:
    """Tokens with stop-words removed (default)."""
    tokens = tokenize(normalize(text))
    if remove_stopwords:
        return [t for t in tokens if t not in STOPWORDS and len(t) > 1]
    return tokens


def word_count(text: str) -> int:
    return len(_TOKEN_RE.findall(normalize(text)))


def extract_urls(text: str) -> list[str]:
    """Return bare hostnames of any URLs found in the raw text."""
    hosts = []
    for match in _URL_RE.findall(text or ""):
        host = match.split("://")[-1].split("/")[0].lower()
        host = host[4:] if host.startswith("www.") else host
        if host:
            hosts.append(host)
    return hosts
