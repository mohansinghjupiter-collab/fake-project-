#!/usr/bin/env python3
"""Turn a raw fake/real news CSV into the project's balanced ``sample_data.csv``.

Input columns expected: ``title``, ``text`` and a label column (``label`` with
REAL/FAKE, or a numeric 0/1 column). Output columns: ``id,title,text,label``
where label is the string ``real`` or ``fake``.

Usage:
    python scripts/prepare_data.py --raw data/raw_fake_or_real_news.csv \
        --out data/sample_data.csv --per-class 800 --max-chars 3000
"""

from __future__ import annotations

import argparse
import os
import sys

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


_FAKE_TOKENS = {"fake", "1", "true", "f", "false_news", "misleading", "fabricated"}


def _normalise_labels(series: pd.Series) -> pd.Series:
    """Map whatever label encoding the source uses onto {real, fake}."""

    def one(v) -> str:
        if isinstance(v, str):
            return "fake" if v.strip().lower() in _FAKE_TOKENS else "real"
        try:
            return "fake" if int(v) == 1 else "real"
        except (TypeError, ValueError):
            return "real"

    return series.map(one)


def build_sample(raw_path: str, out_path: str, per_class: int = 800, max_chars: int = 3000, seed: int = 42) -> str:
    df = pd.read_csv(raw_path)

    label_col = None
    for cand in ("label", "Label", "target", "class"):
        if cand in df.columns:
            label_col = cand
            break
    if label_col is None:
        raise SystemExit(f"No label column found in {raw_path}; columns={list(df.columns)}")

    if "text" not in df.columns:
        raise SystemExit(f"No 'text' column found in {raw_path}; columns={list(df.columns)}")
    title = df["title"] if "title" in df.columns else ""

    work = pd.DataFrame(
        {
            "title": (df["title"].fillna("") if "title" in df.columns else ""),
            "text": df["text"].fillna("").astype(str),
            "label": _normalise_labels(df[label_col]),
        }
    )
    work = work[work["text"].str.split().str.len() >= 25]  # drop stubs
    work["text"] = work["text"].str.slice(0, max_chars)

    parts = []
    for lab in ("real", "fake"):
        pool = work[work["label"] == lab]
        take = min(per_class, len(pool))
        parts.append(pool.sample(n=take, random_state=seed))
    sample = pd.concat(parts).sample(frac=1.0, random_state=seed).reset_index(drop=True)
    sample.insert(0, "id", range(1, len(sample) + 1))

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    sample.to_csv(out_path, index=False)
    size_mb = os.path.getsize(out_path) / 1e6
    print(f"Wrote {len(sample)} rows -> {out_path} ({size_mb:.1f} MB)")
    print(sample["label"].value_counts().to_dict())
    return out_path


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a balanced sample dataset.")
    ap.add_argument("--raw", default=os.path.join(ROOT, "data", "raw_fake_or_real_news.csv"))
    ap.add_argument("--out", default=os.path.join(ROOT, "data", "sample_data.csv"))
    ap.add_argument("--per-class", type=int, default=800)
    ap.add_argument("--max-chars", type=int, default=3000)
    args = ap.parse_args()

    if not os.path.exists(args.raw):
        raise SystemExit(
            f"Raw dataset not found at {args.raw}. Run scripts/fetch_dataset.py first."
        )
    build_sample(args.raw, args.out, per_class=args.per_class, max_chars=args.max_chars)
    return 0


if __name__ == "__main__":
    sys.exit(main())
