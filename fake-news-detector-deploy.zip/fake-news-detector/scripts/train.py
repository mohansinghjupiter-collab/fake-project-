#!/usr/bin/env python3
"""Train the fake-news text classifier and save it to models/detector.joblib.

Usage:
    python scripts/train.py                        # train on data/sample_data.csv
    python scripts/train.py --data big.csv --name detector.joblib
"""

from __future__ import annotations

import argparse
import json
import os
import sys

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from fake_news_detector.model import FakeNewsModel  # noqa: E402


def load_dataset(path: str) -> tuple[list[str], list[int]]:
    df = pd.read_csv(path)
    if "text" not in df.columns or "label" not in df.columns:
        raise SystemExit(f"{path} must have 'text' and 'label' columns; got {list(df.columns)}")

    titles = df["title"].fillna("") if "title" in df.columns else ""
    docs = [
        f"{t}\n{x}".strip()
        for t, x in zip(titles if len(titles) else [""] * len(df), df["text"].fillna(""))
    ]

    def to_int(v) -> int:
        if isinstance(v, str):
            return 1 if v.strip().lower() in {"fake", "1", "true", "f"} else 0
        return int(v)

    labels = [to_int(v) for v in df["label"]]
    return docs, labels


def main() -> int:
    ap = argparse.ArgumentParser(description="Train the fake-news classifier.")
    ap.add_argument("--data", default=os.path.join(ROOT, "data", "sample_data.csv"))
    ap.add_argument("--name", default="detector.joblib")
    ap.add_argument("--test-size", type=float, default=0.2)
    args = ap.parse_args()

    docs, labels = load_dataset(args.data)
    print(f"Loaded {len(docs)} documents ({sum(labels)} fake / {len(labels) - sum(labels)} real)")

    model = FakeNewsModel(calibrate=True).build()
    print("Training TF-IDF (word + char) + stylometry -> calibrated logistic regression ...")
    metrics = model.train(docs, labels, test_size=args.test_size, do_cv=True)

    print("\n=== Held-out test set ===")
    print(metrics.report)
    print(json.dumps(metrics.as_dict(), indent=2))

    out = model.save(os.path.join(ROOT, "models", args.name))
    print(f"\nSaved model -> {out}")

    metrics_path = os.path.join(ROOT, "models", "metrics.json")
    payload = {"dataset": os.path.basename(args.data), "n_documents": len(docs), **metrics.as_dict()}
    with open(metrics_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    print(f"Saved metrics -> {metrics_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
